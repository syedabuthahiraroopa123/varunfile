/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["*"],

  extend: {
    theme: {},
  },
  plugins: [],
}

